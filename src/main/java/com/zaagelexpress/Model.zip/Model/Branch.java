/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.zaagelexpress.Model;

/**
 *
 * @author saada1
 */
public class Branch extends EndPoint {

    public Branch(String branchName, String address, String phone, ServiceArea area) {
        super(branchName, address, phone, area);
    }

}
